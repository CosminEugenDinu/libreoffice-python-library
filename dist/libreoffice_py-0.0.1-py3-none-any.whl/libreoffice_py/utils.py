"""
libreoffice_py.utils

This module provides utility functions.
"""

